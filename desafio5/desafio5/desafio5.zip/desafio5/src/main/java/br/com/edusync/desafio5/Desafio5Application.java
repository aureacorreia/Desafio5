package br.com.edusync.desafio5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Desafio5Application {

	public static void main(String[] args) {
		SpringApplication.run(Desafio5Application.class, args);
	}

}
